<template>
    <div>
      工资张涛管理
    </div>
</template>

<script>
    export default {
        name: "SalSob"
    }
</script>

<style scoped>

</style>
