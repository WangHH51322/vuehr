<template>
    <div>
      认识记录统计
    </div>
</template>

<script>
    export default {
        name: "StaRecord"
    }
</script>

<style scoped>

</style>
