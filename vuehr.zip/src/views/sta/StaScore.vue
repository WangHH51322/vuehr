<template>
    <div>
      员工积分统计
    </div>
</template>

<script>
    export default {
        name: "StaScore"
    }
</script>

<style scoped>

</style>
