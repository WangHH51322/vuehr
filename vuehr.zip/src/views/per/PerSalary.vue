<template>
    <div>
      员工挑衅
    </div>
</template>

<script>
    export default {
        name: "PreSalary"
    }
</script>

<style scoped>

</style>
