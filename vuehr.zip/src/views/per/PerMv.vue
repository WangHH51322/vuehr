<template>
    <div>
      调动
    </div>
</template>

<script>
    export default {
        name: "PreMv"
    }
</script>

<style scoped>

</style>
