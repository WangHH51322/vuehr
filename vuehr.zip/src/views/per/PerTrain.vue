<template>
    <div>
      员工培训
    </div>
</template>

<script>
    export default {
        name: "PreTrain"
    }
</script>

<style scoped>

</style>
