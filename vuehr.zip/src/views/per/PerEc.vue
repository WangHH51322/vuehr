<template>
    <div>
      员工奖惩
    </div>
</template>

<script>
    export default {
        name: "PerEC"
    }
</script>

<style scoped>

</style>
