<template>
    <div>
      基本资料
    </div>
</template>

<script>
    export default {
        name: "EmpBasic"
    }
</script>

<style scoped>

</style>
